export interface Child {
  id: string;
  name: string;
  birthDate: string;
  gender: 'male' | 'female' | 'other';
  photoUrl?: string;
  growthRecords: GrowthRecord[];
  milestones: MilestoneRecord[];
}

export interface GrowthRecord {
  id: string;
  date: string;
  weight?: number; // kg
  height?: number; // cm
  headCircumference?: number; // cm
}

export interface MilestoneRecord {
  id: string;
  milestoneId: string;
  achievedDate: string;
}

export interface FamilyMember {
  id: string;
  name: string;
  role: string;
  childIds: string[];
  photoUrl?: string;
}

export interface JournalEntry {
  id: string;
  childId: string;
  date: string;
  feeding?: string;
  sleep?: string;
  mood?: 'happy' | 'neutral' | 'fussy' | 'sick';
  diaper?: number;
  notes?: string;
}

export type AgeStage =
  | 'newborn'     // 0-3 months
  | 'infant'      // 3-12 months
  | 'toddler'     // 1-3 years
  | 'preschool'   // 3-5 years
  | 'school-age'  // 5-10 years
  | 'preteen'     // 10-13 years
  | 'teen';        // 13-15 years

export interface GuidanceCategory {
  id: string;
  icon: string;
  title: string;
  color: string;
}

export interface GuidanceItem {
  stage: AgeStage;
  categoryId: string;
  items: string[];
}

export type Language = 'en' | 'es' | 'fr' | 'ar' | 'hi' | 'ur' | 'bn';

export interface AppSettings {
  language: Language;
  theme: 'light' | 'dark' | 'system';
}
